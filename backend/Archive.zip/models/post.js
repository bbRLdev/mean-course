/* jshint esversion: 6 */

const mongoose = require('mongoose');


const postSchema = mongoose.Schema({
    title: { type: String, required: true },
    content: { type: String, required: true },
    imagePath: { type: String, required: true },
    creator: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
});

// has to start w uppercase char
module.exports = mongoose.model('Post', postSchema);